<?php
/**
 * The header.
 *
 * This is the template that displays all of the <head> section and everything up until main.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>
<!doctype html>
<html <?php language_attributes(); ?> <?php twentytwentyone_the_html_classes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/assets/css/style.css?ver=<?php echo date('h:i:s') ?>"/>
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/assets/css/media.css?ver=<?php echo date('h:i:s') ?>"/>
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/assets/css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/assets/css/owl.theme.default.min.css"/>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css"/>
	<link rel="stylesheet" href="<?php bloginfo('template_url') ?>/assets/css/jquery.multiselect.css"/>
	<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-1R18QSHDDZ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-1R18QSHDDZ');
</script>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header> 
    <nav class="navbar navbar-expand-lg">
        <div class="container position-relative">
            <a class="navbar-brand" href="<?php echo site_url(); ?>/"><img src="<?php the_field('logo', 'options'); ?>" alt="logo"></a>
            <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#Menu_sidebar">
                <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
            </button>
            <div class="collapse navbar-collapse" id="Menu_sidebar">
                <?php
				/* wp_nav_menu( array(
				'menu'              => 'Main Menu',
				'menu_class'        => 'navbar-nav ml-auto',
				'walker'          => new bs4navwalker())
				); */
				?>
				<?php
					wp_nav_menu(
					array(
					'menu' => 'Main Menu',
					'container'       => '',
					'menu_class'      => 'navbar-nav ml-auto',
					'depth'           => 4,
    				'walker'        => new wp_bootstrap_navwalker()
					)
					);
					?>
            </div>
            <div class="search_contact">
                <ul>
                    <li><button type="button" class="search_btn"><img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/search-icon.svg"></a></li>
                     <li class="contact_btn_desktop"><a href="/contact-us" class="nav-link">Contact Us</a></li>
                </ul>
                <div id="search"> 
                    <form role="search" id="searchform" action="/" method="get">
                        <span class="close"><i class="fas fa-times"></i></span>
                        <input value="<?php the_search_query(); ?>" name="s" type="search" placeholder="Search..."/>
                    </form>
                </div>
            </div>
        </div>
    </nav>  
</header>

<?php get_header(); ?>
<div class="page-content">
<section class="banner_sec inner_banner blog_banner new_banner py_3 wi_full">
    <img src="/wp-content/uploads/2024/05/blog-banner.png" class="desktop_banner w-100">
    <img src="/wp-content/uploads/2024/05/blog-banner-mobile.png" class="mobile_banner w-100">
    <div class="banner__wrap">
        <div class="container-xxl">
            <div class="banner_title text-center mb-3 small_title case_title">
                <h1>Blue Orange <span>Case Studies</span></h1>
            </div>
            <div class="banner_content text-center">
                <p>Stay up to date with our latest news</p>
                <?php get_template_part( 'template-parts/hubspot-newsletter-form' ); ?>
            </div>
        </div>
    </div>
</section>
<section class="insight_sec blog_sec wi_full py_3 sec_after_sec">
    <div class="container">
         <div class="blog_filter wi_full">
            <form class="group" role="search" method="get" action="<?php echo site_url(); ?>/">
               <div class="row">
                  <div class="col-12 col-sm-6 col-lg-3">
                     <div class="blog_search form-group">
                        <input type="text" name="post_type" value="case-studies" / style="display: none;">
                        <input type="text" value="" name="s" placeholder="Search" class="form-control" />
                        <input type="hidden" value="case_studies_tags" name="tax_blog_tags" />
                        <input type="hidden" value="technology_studies_tags" name="tax_technology_tags" />
                        <input type="hidden" value="industries_studies_tags" name="tax_industries_tags" />
                     </div>
                  </div>
                  <div class="col-12 col-sm-6 col-lg-2">
                     <div class="blog_tags form-group">
                        <?php
                           $terms = get_terms([
                                 'taxonomy' => 'case_studies_tags',
                                 'hide_empty' => false,
                           ]);
                         ?>
                        <select name="tags[]" class="form-control selectOpt" id="select_services" data-placeholder="Select Services" multiple>
                           <?php
                              foreach ($terms as $term){ ?>
                                 <option value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
                           <?php } ?>
                        </select>
                     </div>
                  </div>
				     <div class="col-12 col-sm-6 col-lg-2">
                     <div class="blog_tags form-group">
                        <?php
                           $terms2 = get_terms([
                               'taxonomy' => 'technology_studies_tags',
                               'hide_empty' => false,
                           ]);
                         ?>
                        <select name="techtags[]" class="form-control selectOpt" id="select_technology" data-placeholder="Select Technologies" multiple>
                           <?php
                              foreach ($terms2 as $term){ ?>
                                 <option value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
                           <?php } ?>
                        </select>
                     </div>
                  </div>
				      <div class="col-12 col-sm-6 col-lg-2">
                     <div class="blog_tags form-group">
                        <?php
                           $terms2 = get_terms([
                               'taxonomy' => 'industries_studies_tags',
                               'hide_empty' => false,
                           ]);
                         ?>
                        <select name="indtags[]" class="form-control selectOpt" id="select_industry" data-placeholder="Select Industries" multiple>
                           <?php
                              foreach ($terms2 as $term){ ?>
                                 <option value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
                           <?php } ?>
                        </select>
                     </div>
                  </div>
                  <div class="col-12 col-sm-6 col-lg-3">
                     <div class="submit_btn d-flex justify-content-end">
                        <input value="Search" class="button blue_btn" type="submit">
                     </div>
                  </div>
               </div>
            </form>
         </div>

        <div class="blog_wrapper row">
            <?php if ( have_posts() ) { ?>
               <?php while ( have_posts() ) {
                  the_post(); ?>
                  <?php get_template_part( 'template-parts/content/content-case-studies-block' ); ?>
               <?php } ?>
            <?php wp_reset_postdata();
             the_posts_pagination(); 
         } ?>
        </div>
    </div>
</section>
</div>
<?php get_footer(); ?>
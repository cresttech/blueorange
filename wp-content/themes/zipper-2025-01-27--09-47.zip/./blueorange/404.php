<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header();
?>

<section class="error_sec wi_full py_3" style="background: url(<?php bloginfo('template_url') ?>/assets/images/error-bg-desktop.png) no-repeat center; background-size: cover;">
    <div class="container-xxl">
        <div class="sec_content text-center">
			<h1><span>404</span> Page Not Found</h1>
			<p>Unfortunately, we can't find the page you're looking for....</p>
			<div class="btn_block justify-content-center">
				<a href="<?php echo site_url(); ?>/" class="button blue_btn">Go back to homepage</a>
			</div>
        </div>
    </div>
</section>

<?php
get_footer();
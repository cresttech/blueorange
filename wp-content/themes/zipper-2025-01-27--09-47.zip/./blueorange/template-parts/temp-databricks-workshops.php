<?php
/*
Template Name: Databricks Workshops Page
*/
get_header();
?>
<div class="page-content">
    <section class="banner_sec inner_banner partner_banner wi_full">
    <div class="container-xxl">
        <div class="banner_title no_indent text-center mb-3">
            <h1><?php the_field('heading'); ?></h2>
        </div>
    </div>
</section>

<section class="accelrate_sec wi_full py_3">
    <div class="container-xxl">
        <div class="max_width">
            <div class="sec_title text-center mb-0">
                <h3 class="mb-3 mt-3"><?php the_field('heading_1'); ?></h3>
                <?php the_field('content_1'); ?>
            </div>
        </div>
    </div>
</section>
<section class="why_attend wi_full py_3 pt-0">
    <div class="container-xxl">
        <div class="sec_title text-center mb-0">
            <h2><?php the_field('heading_2'); ?></h2>
        </div>
        <div class="row attend_list">
			<?php if( have_rows('content_2') ):
			while ( have_rows('content_2') ) : the_row();	?>
            <div class="col-12 col-sm-6 col-lg-4 attend_item">
                <div class="item_inner ul_tick">
                    <img src="<?php the_sub_field('icon'); ?>" class="atnd_itm mb-3">
                    <h3><?php the_sub_field('title'); ?></h3>
                    <?php the_sub_field('text'); ?>
                </div>
            </div>
			<?php endwhile; endif;?>
        </div>
    </div>
</section>
<section class="workshop_sec wi_full py_3 bg_bluee">
    <div class="container-xxl">
        <div class="sec_title text-center mb-0">
            <h2><?php the_field('heading_3'); ?></h2>
        </div>
        <div class="row attend_list">
			<?php if( have_rows('content_3') ):
			while ( have_rows('content_3') ) : the_row();	?>
            <div class="col-12 col-sm-6 col-lg-4 attend_item">
                <div class="item_inner ul_tick">
                    <h3><?php the_sub_field('title'); ?></h3>
                    <?php the_sub_field('text'); ?>
                </div>
            </div>
			<?php endwhile; endif;?>
        </div>
        <div class="sec_title mb-0 mt-5 text-center">
            <p><?php the_field('text'); ?></p>
            <div class="btn_block justify-content-center mt-2">
                <a href="/contact-us/" class="button blue_btn">Contact Us <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-white.svg"></a>
            </div>
        </div>
    </div>
</section>
<section class="how_works_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title text-center max_width mb-0">
            <h2><?php the_field('heading_4'); ?></h2>
        </div>
        <div class="row how_list">
			<?php if( have_rows('content_4') ):
			while ( have_rows('content_4') ) : the_row();	?>
            <div class="col-12 col-sm-4 col-lg-4 how_item">
                <div class="item_inner text-center">
                   <h3><?php the_sub_field('title'); ?></h3>
                    <?php the_sub_field('text'); ?>
                </div>
            </div>
			<?php endwhile; endif;?>
        </div>
    </div>
</section>
<section class="why_section wi_full py_3 bg_bluee">
    <div class="container-xxl">
        <div class="max_width">
            <div class="sec_title text-center mb-0">
                <h2><?php the_field('heading_5'); ?></h2>
                <?php the_field('content_5'); ?>
            </div>
            <div class="ul_tick mt-4">
                <?php the_field('list_content'); ?>
            </div>
        </div>
    </div>
</section>
<section class="reserve_spot wi_full py_3" id="request-spot">
    <div class="container-xxl">
        <div class="sec_title text-center max_width mb-0">
            <h2><?php the_field('heading_6'); ?></h2>
            <?php the_field('content_6'); ?>
            <div class="btn_block justify-content-center">
                <a href="<?php the_field('button_link'); ?>" class="button blue_btn" target="_blank"><?php the_field('button_text'); ?> <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-white.svg"></a>
            </div>
        </div>
    </div>
</section>
</div>
<?php get_footer(); ?>
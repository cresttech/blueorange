<?php
/*
Template Name: Data Migration
*/
get_header();
?>
<div class="page-content services_page">
<section class="banner_sec inner_banner services_banner new_banner wi_full">
    <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-migration-desktop.png" class="desktop_banner w-100">
    <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-migration-mobile.png" class="mobile_banner w-100">
    <div class="banner__wrap">
        <div class="container-xxl">
            <div class="banner_title text-center mb-3 title_service">
                <h1>Data <span>Migrations</span></h1>
            </div>
            <div class="banner_content text-center">
                <p>Navigate the complexities of Cloud Data Platform Migration with Blue Orange, where our deep expertise in Databricks, AWS, Snowflake, and Microsoft Azure, coupled with our history of handling a wide array of legacy platforms, sets the stage for your seamless transition. We understand the unique challenges of shifting from traditional enterprise data warehouses to advanced cloud solutions.</p>
                <div class="btn_block justify-content-center mt_2">
                    <a href="/contact-us/" class="button orange_btn">Get Started</a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="data_migration wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>Data Migrations Services</h2>
            <p>Discover the full spectrum of our cloud data services, designed to guide your journey from assessment through implementation to optimization. With Blue Orange, ensure a smooth, efficient transition to the cloud, maximizing performance and value from your data assets.</p>
        </div>
        <div class="rel_ser_List row">
            <div class="col-12 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/cloud-computing.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Cloud Data Migration  Assessment</h3>
                    <p>Evaluate your readiness for cloud migration with our comprehensive assessment service. We analyze your current infrastructure and data workflows to develop a strategic migration plan tailored to your needs.</p>
                </a>
            </div>
            <div class="col-12 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-migration.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Cloud Data Migration Implementation</h3>
                    <p>Seamlessly transition your data to the cloud with our expert implementation services. We manage the entire migration process, ensuring a secure, efficient, and successful transfer of your data assets.</p>
                </a>
            </div>
            <div class="col-12 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-integration.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Cloud Data Platform  Optimization</h3>
                    <p>Maximize the performance and efficiency of your cloud data platform with our optimization services. We fine-tune your environment to enhance data processing, storage, and analysis, driving improved business outcomes.</p>
                </a>
            </div>
        </div>
        <div class="btn_block justify-content-center">
            <a href="/contact-us/" class="button blue_btn">Learn More</a>
        </div>
    </div>
</section>
<section class="overview_sec wi_full py_3">
    <div class="container-xxl">
        <div class="overview_detail">
            <h2>The Blue Orange Approach.</h2>
        </div>
        <ul>
            <li>
                <h4>Discovery</h4>
                <p>Leverage automated profiling tools to uncover insights into your existing systems, evaluate workloads on legacy platforms, and forecast consumption costs.</p>          
            </li>
            <li>
                <h4>Assessment</h4>
                <p>Utilize advanced analyzers to conduct an in-depth examination of code complexity, aiding in the accurate estimation of migration project expenses.</p>
            </li>
            <li>
                <h4>Strategy</h4>
                <p>With expert input from our data platform solutions specialists, determine the best technology alignments and devise strategic migration paths for each legacy source.</p>               
            </li>
            <li>
                <h4>Production Pilot</h4>
                <p>Implement a pilot project to test specific use cases, employing code conversion tools as needed to adapt legacy code for compatibility.</p>          
            </li>
            <li>
                <h4>Execute</h4>
                <p>After validating the pilot, we apply the established process to all workloads, ensuring efficient migration.&nbsp;</p>
            </li>
        </ul>
        <div class="btn_block">
            <a href="/contact-us/" class="button blue_btn v_dsktop">Book a call <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icon-arrow-white.svg"></a>
        </div>
    </div>
</section>
<section class="migration_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>Migrating to Databricks</h2>
            <p>Reduce costs, innovate faster, and simplify your data platform by migrating to the Databricks Lakehouse. Whether you are on-premise and looking to make a move to the cloud to take advantage of the latest capabilities and future-proof your analytics architecture,  or you are in the cloud already.</p>
            <p> But looking to optimize your cost and accelerate your organization’s analytics agenda by simplifying and streamlining your end-to-end process with Databricks, Blue Orange can help you make the move. Our years of expertise in implementing Databricks solutions can help you stick the landing on your migration and be enabled to see value and ROI quickly!</p>
        </div>
        <div class="rel_ser_List row">
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Simplify your data platform</h3>
                    <p>Get a single modern platform for all your data, analytics, and AI use cases. Unify governance and the user experience across clouds and data teams.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Scale cost-effectively</h3>
                    <p>Stop managing servers, and scale on demand with serverless. Run data warehousing at scale with up to 12x better price/performance.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Accelerate innovation</h3>
                    <p>Build AI, ML, and real-time analytics capabilities faster with collaborative, self-service tools and open-source technologies such as MLflow and Apache Spark™.</p>
                </a>
            </div>
        </div>
        <div class="btn_block justify-content-center">
            <a href="/contact-us/" class="button orange_btn">Learn More</a>
        </div>
    </div>
</section>
<section class="casestudy_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title btn_title">
            <h2>Case Studies</h2>
            <a href="<?php the_field('button_link_4'); ?>" class="button orange_btn v_dsktop"><?php the_field('button_text_4'); ?></a>
        </div>
        <div class="casestudy_wrapper">
            <?php
            $postids = get_field('case_studies');
            $args = array( 'post_type' => 'case-studies' , "order" => "DESC", 'posts_per_page' => '3', "post__in" => $postids);
            $query = new WP_Query( $args ); 
            if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : 
            $query->the_post();
            $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
            ?>
            <div class="item case_item">
                <a href="<?php the_permalink(); ?>" class="item_inner">
                    <div class="item_icon">
                        <img src="<?php echo $featured_img_url; ?>" alt="#">
                    </div>
                    <div class="item_text">
                        <h3><?php the_title(); ?></h3>
                        <?php
                              $excerpt       = get_the_excerpt();
                              $excerpt       = substr( $excerpt, 0, 100 );
                              $short_excerpt = substr( $excerpt, 0, strrpos( $excerpt, ' ' ) );
                              if ( ! empty( $short_excerpt ) ) { ?>
                                    <p><?php echo esc_html( $short_excerpt ); ?>&hellip;</p>
                           <?php } ?>
                        <div class="more_btn circle_morebtn">
                            <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-blue.svg">
                        </div>
                    </div>
                </a>
            </div>
            <?php endwhile; endif;  wp_reset_postdata(); ?>
        </div>
        <div class="btn_block v_mobile">
            <a href="<?php the_field('button_link_4'); ?>" class="button orange_btn"><?php the_field('button_text_4'); ?></a>
        </div>
    </div>
</section>
<section class="industry_sec wi_full">
    <div class="container-xxl">
        <div class="row align-items-baseline">
            <div class="col-12 col-lg-6">
                <div class="sec_title faq_title">
                    <h2>Frequently <br />asked questions</h2>
                    <div class="btn_block v_dsktop">
                        <a href="#" class="button orange_btn">Support</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="accordion_wrapper">
                    <div class="accordion faq_accordion" id="accordion" role="tablist" aria-multiselectable="true">
                        <div class="card">
                            <div class="card-header p-0" role="tab" id="accordion1">
                                <h3 class="collapsed" data-toggle="collapse" data-target="#accordion__1" role="button" aria-controls="accordion__1">How long are data strategy engagements?</h3>
                            </div>
                            <div id="accordion__1" class="collapse" role="tabpanel" aria-labelledby="accordion1" data-parent="#accordion">
                                <div class="card-body">
                                    <p>Typically 3-4 weeks. Text for example: By leveraging our approach to deploying machine learning (ML) workloads, we’ve boosted predictive analytics for a leading entertainment provider.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="btn_block v_mobile">
            <a href="#" class="button orange_btn">Support</a>
        </div>
    </div>
</section>
</div>
<?php get_footer(); ?>
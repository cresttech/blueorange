<?php
/*
Template Name: Leadership Page
*/
get_header();
?>
<div class="page-content">
<section class="banner_sec inner_banner new_banner banner_max_h wi_full">
    <img src="<?php the_field('image_1'); ?>" class="desktop_banner w-100">
    <img src="<?php the_field('image_mobile'); ?>" class="mobile_banner w-100">
    <div class="banner__wrap">
        <div class="container-xxl">
            <div class="banner_title leader_ptitle text-center mb-3 small_title">
                <h1><?php the_field('heading_1'); ?></h1>
            </div>
            <div class="banner_content text-center">
                <?php the_field('content_1'); ?>
                <div class="btn_block justify-content-center">
                    <a href="<?php the_field('button_link_2'); ?>" class="button orange_btn" target="_blank"><?php the_field('button_text_2'); ?></a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="team_sec wi_full py_3 sec_after_sec">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2><?php the_field('heading_3'); ?></h2>
            <?php the_field('content_3'); ?>
        </div>
        <div class="row team_List mt_2">
            <?php if( have_rows('team') ):
            while ( have_rows('team') ) : the_row();    ?>
            <div class="col-12 col-sm-6 col-lg-4 team_item">
                <div class="item_inner">
                    <div class="mem_img">
                        <img src="<?php the_sub_field('image'); ?>">
                    </div>
                    <h3><?php the_sub_field('heading'); ?></h3>
                    <a href="<?php the_sub_field('linkedin'); ?>" target="_blank" class="mem_pos">
                        <span><?php the_sub_field('position'); ?></span>
                        <img src="<?php bloginfo('template_url') ?>/assets/images/linkedin-blue.png">
                    </a>
                    <?php the_sub_field('content'); ?>
                </div>
            </div>
            <?php endwhile; endif;?>
        </div>
    </div>
</section>
<section class="join_sec wi_full">
    <div class="container-xxl">
        <div class="sec__bg" style="background: url(<?php the_field('background'); ?>) no-repeat center; background-size: cover;">
            <div class="text-center max_width text-white">
                <h2 class="text-white"><?php the_field('heading_2'); ?></h2>
                <p><?php the_field('content_2'); ?></p>
                <div class="btn_block justify-content-center">
                    <a href="<?php the_field('button_link'); ?>" class="button orange_btn"><?php the_field('button_text'); ?></a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="contact_sec wi_full mt_3">
    <div class="container-xxl">
        <div class="sec_title">
            <h2><?php the_field('contact_title'); ?></h2>
        </div>
        <div class="contact_form">
            <div class="row">
                <div class="col-12 col-md-5 col-lg-6 info_column">
                    <div class="contct_addres">
                        <?php the_field('contact_content'); ?>
                        <ul class="mt_3">
                            <li>
                                <img src="<?php bloginfo('template_url') ?>/assets/images/orange-email.png">
                                <a href="mailto:<?php the_field('email','option'); ?>"><?php the_field('email','option'); ?></a>
                            </li>
                            <li>
                                <img src="<?php bloginfo('template_url') ?>/assets/images/orange-phone.png">
                                <a href="tel:<?php the_field('phone','option'); ?>"><?php the_field('phone','option'); ?></a>
                            </li>
                            <li>
                                <img src="<?php bloginfo('template_url') ?>/assets/images/orange-location.png">
                                <address><?php the_field('address','option'); ?></address>
                            </li>
                        </ul>
                        <div class="contact_social mt_3">
                            <!-- <a href="https://twitter.com/BlueOrangeData"><img src="<?php bloginfo('template_url') ?>/assets/images/twitter-alt.png"></a>
                            <a href="https://www.linkedin.com/company/blue-orange-digital"><img src="<?php bloginfo('template_url') ?>/assets/images/linkedin-alt.png"></a> -->

                            <?php if( have_rows('social_links','option') ):
                            while ( have_rows('social_links','option') ) : the_row(); 
                                $url = parse_url(get_sub_field('link'));
                                $social_icon = '';
                                if(strcmp($url['host'],'www.linkedin.com') == 0){
                                    $social_icon = 'wp-content/uploads/2024/04/icon-linkedin.svg';
                                }
                                if(strcmp($url['host'],'twitter.com') == 0){
                                    $social_icon = 'wp-content/uploads/2024/04/icon-twitter.svg';
                                }
								if(strcmp($url['host'],'medium.com') == 0){
                                    $social_icon = 'wp-content/uploads/2024/06/medium-icon.svg';
                                }
								if(strcmp($url['host'],'lu.ma') == 0){
                                    $social_icon = 'wp-content/uploads/2024/06/Vector.svg';
                                }
								if(strcmp($url['host'],'www.youtube.com') == 0){
                                    $social_icon = 'wp-content/uploads/2024/06/youtube_orange.svg';
                                }
                            ?>
                            <a href="<?php the_sub_field('link'); ?>" target="_blank">
                                <img src="<?php echo site_url(); ?>/<?php echo $social_icon; ?>">
                            </a>
                            <?php endwhile; endif;?>

                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-7 col-lg-6 form_column">
                    <script charset="utf-8" type="text/javascript" src="//js.hsforms.net/forms/embed/v2.js"></script>
                    <script>
                      hbspt.forms.create({
                        region: "na1",
                        portalId: "7577521",
                        formId: "e1c6a1b6-052e-432d-9284-9c5864683740"
                      });
                    </script>
                </div>
            </div>
        </div>
    </div>
</section>
</div>
<?php get_footer(); ?>
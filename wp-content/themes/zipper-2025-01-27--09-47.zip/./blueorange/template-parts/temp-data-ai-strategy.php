<?php
/*
Template Name: Data AI & Strategy
*/
get_header();
?>
<div class="page-content services_page">
<section class="banner_sec inner_banner services_banner new_banner wi_full">
    <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-strategy-desktop.png" class="desktop_banner w-100">
    <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-strategy-mobile.png" class="mobile_banner w-100">
    <div class="banner__wrap">
        <div class="container-xxl">
            <div class="banner_title text-center mb-3 title_service">
                <h1><h1>Data <span>& AI Strategy</span></h1></h1>
            </div>
            <div class="banner_content text-center">
                <p>Crafting the right strategy from the outset is crucial for success in data transformation. A flawed strategy can accumulate technical debt, escalating costs, and lower adoption. Leveraging Blue Orange’s years of expertise and insights gained from numerous successes, our team can work collaboratively with your team to answer the questions and intricacies involved in this journey.</p>
                <div class="btn_block justify-content-center mt_2">
                    <a href="/contact-us/" class="button orange_btn">Get Started</a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="data__section wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>Heading</h2>
            <p>Our approach, refined through engagements across many clients, transcends mere technological prowess. It encompasses a holistic approach of infrastructure knowledge, experienced personnel, and streamlined processes. We are eager to share our wealth of knowledge, experience, and hands-on methodology to ensure that your strategy is built for efficacy from the very beginning.</p>
        </div>
        <div class="btn_block justify-content-center">
            <a href="/contact" class="button blue_btn">Book a call  <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-white.svg"></a>
        </div>
    </div>
</section>
<section class="bo_help wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>Blue Orange can help.</h2>
            <p>We have experts who are ready to dive in to match your Data and AI Strategy to your short, and long-term business and technology goals. Our proven process will take a holistic view of your data ecosystem, ask the hard questions to uncover what’s holding your organization from achieving its goals, and craft a tailored strategy that combines clearly defining objectives, current state assessment, data governance, data architecture, and infrastructure, and selecting the tools and processes to make it all a reality.</p>
        </div>
        <div class="btn_block justify-content-center">
            <a href="" class="button orange_btn">Learn More</a>
        </div>
    </div>
</section>
<section class="strategy_services wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title mb-5">
            <h2>Data &amp; AI strategy services.</h2>
        </div>
        <div id="strategy_services" class="owl-carousel">
            <div class="item">
                <div class="item_inner">
                    <div class="row">
                        <div class="col-12">
                            <div class="services_img services1">
                                <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/Blue-orance-image1.png">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="services_detail mt-5">
                                <h3>Data Strategy</h3>
                                <p>Our Data Strategy service provides a comprehensive roadmap to harness the full potential of your data assets. We focus on aligning your data initiatives with business objectives, ensuring robust data governance, quality, and architecture to drive actionable insights and competitive advantage.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="item_inner">
                    <div class="row">
                        <div class="col-12">
                            <div class="services_img services1">
                                <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/Blue-orance-image2.png">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="services_detail mt-5">
                                <h3>AI Strategy</h3>
                                <p>This service is designed to help you navigate the complexities of integrating artificial intelligence into your business. We assist in identifying high-impact use cases, developing ethical AI frameworks, and creating scalable models that align with your strategic goals, enhancing innovation and operational efficiency.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="item_inner">
                    <div class="row">
                        <div class="col-12">
                            <div class="services_img services1">
                                <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/Blue-orance-image3.png">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="services_detail mt-5">
                                <h3>Analytics Strategy</h3>
                                <p>The Analytics Strategy service offers a tailored approach to transforming data into actionable intelligence. We emphasize the development of advanced analytics capabilities, including predictive analytics and business intelligence, to support data-driven decision-making and unlock new opportunities for growth.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="overview_sec wi_full py_3">
    <div class="container-xxl">
        <div class="overview_detail">
            <h2>Overview of the Blue Orange Approach.</h2>
            <p>Achieving success in AI, data, and analytics requires more than just technical expertise; it demands a clear, unified strategy that your entire organization supports. At Blue Orange, we understand this challenge. Our team of experts will not only guide you but also work alongside your team, fostering a deep understanding and crafting a tailor-made strategy to ensure your business thrives. With Blue Orange as your partner, you can expect a transformative journey, culminating in a comprehensive strategic plan, all within a 4-8 week period.</p>
        </div>
        <ul>
            <li>
                <h4>Discovery</h4>        
            </li>
            <li>
                <h4>Kick off</h4>
            </li>
            <li>
                <h4>Tool Selection</h4>              
            </li>
            <li>
                <h4>Team Interviews</h4>        
            </li>
            <li>
                <h4>Collaborative Roadmapping</h4>
            </li>
        </ul>
    </div>
</section>
<section class="casestudy_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title btn_title">
            <h2>Case Studies</h2>
            <a href="<?php the_field('button_link_4'); ?>" class="button orange_btn v_dsktop"><?php the_field('button_text_4'); ?></a>
        </div>
        <div class="casestudy_wrapper">
            <?php
            $postids = get_field('case_studies');
            $args = array( 'post_type' => 'case-studies' , "order" => "DESC", 'posts_per_page' => '3', "post__in" => $postids);
            $query = new WP_Query( $args ); 
            if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : 
            $query->the_post();
            $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
            ?>
            <div class="item case_item">
                <a href="<?php the_permalink(); ?>" class="item_inner">
                    <div class="item_icon">
                        <img src="<?php echo $featured_img_url; ?>" alt="#">
                    </div>
                    <div class="item_text">
                        <h3><?php the_title(); ?></h3>
                        <?php
                              $excerpt       = get_the_excerpt();
                              $excerpt       = substr( $excerpt, 0, 100 );
                              $short_excerpt = substr( $excerpt, 0, strrpos( $excerpt, ' ' ) );
                              if ( ! empty( $short_excerpt ) ) { ?>
                                    <p><?php echo esc_html( $short_excerpt ); ?>&hellip;</p>
                           <?php } ?>
                        <div class="more_btn circle_morebtn">
                            <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-blue.svg">
                        </div>
                    </div>
                </a>
            </div>
            <?php endwhile; endif;  wp_reset_postdata(); ?>
        </div>
        <div class="btn_block v_mobile">
            <a href="<?php the_field('button_link_4'); ?>" class="button orange_btn"><?php the_field('button_text_4'); ?></a>
        </div>
    </div>
</section>
<section class="industry_sec wi_full">
    <div class="container-xxl">
        <div class="row align-items-baseline">
            <div class="col-12 col-lg-6">
                <div class="sec_title faq_title">
                    <h2>Frequently <br />asked questions</h2>
                    <div class="btn_block v_dsktop">
                        <a href="#" class="button orange_btn">Support</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="accordion_wrapper">
                    <div class="accordion faq_accordion" id="accordion" role="tablist" aria-multiselectable="true">
                        <div class="card">
                            <div class="card-header p-0" role="tab" id="accordion1">
                                <h3 class="collapsed" data-toggle="collapse" data-target="#accordion__1" role="button" aria-controls="accordion__1">How long are data strategy engagements? </h3>
                            </div>
                            <div id="accordion__1" class="collapse" role="tabpanel" aria-labelledby="accordion1" data-parent="#accordion">
                                <div class="card-body">
                                    <p>Typically 3-4 weeks.</p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header p-0" role="tab" id="accordion2">
                                <h3 class="collapsed" data-toggle="collapse" data-target="#accordion__2" role="button" aria-controls="accordion__2">How much time will be required from my team?</h3>
                            </div>
                            <div id="accordion__2" class="collapse" role="tabpanel" aria-labelledby="accordion2" data-parent="#accordion">
                                <div class="card-body">
                                    <p><span style="font-weight: 400">About 5 hours a week from core team members, 2-3 hours total for any team members you that need to be interviewed by our team.</span></p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header p-0" role="tab" id="accordion3">
                                <h3 class="collapsed" data-toggle="collapse" data-target="#accordion__3" role="button" aria-controls="accordion__3">What is the deliverable for a strategy engagement?</h3>
                            </div>
                            <div id="accordion__3" class="collapse" role="tabpanel" aria-labelledby="accordion3" data-parent="#accordion">
                                <div class="card-body">
                                    <p><span style="font-weight: 400">A written data strategy report, 1 collaborative brainstorming session, and a final presentation to your team.</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="btn_block v_mobile">
            <a href="#" class="button orange_btn">Support</a>
        </div>
    </div>
</section>
</div>
<?php get_footer(); ?>
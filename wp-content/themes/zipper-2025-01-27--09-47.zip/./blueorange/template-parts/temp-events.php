<?php
/*
Template Name: Event Page
*/
get_header();
?>
<div class="page-content">
<section class="banner_sec inner_banner fintech__banner new_banner wi_full">
    <img src="<?php the_field('banner_image'); ?>" class="desktop_banner w-100">
    <img src="<?php the_field('image_mobile'); ?>" class="mobile_banner w-100">
    <div class="banner__wrap">
        <div class="container-xxl">
            <div class="banner_title text-center mb-3 event_title">
                <h1><?php the_field('heading'); ?></h1>
            </div>
        </div>
    </div>
</section>
<section class="event_data_sec wi_full mt_3">
    <div class="container-xxl">
        <div class="row ed_row_list">
			<?php if( have_rows('content_1') ):
			while ( have_rows('content_1') ) : the_row();	?>
            <div class="col-12 col-md-6 ed_item">
                <div class="ed_inner">
                    <h4 class="text_orange"><?php the_sub_field('heading'); ?></h4>
                    <h3><?php the_sub_field('sub_heading'); ?></h3>
                    <?php the_sub_field('text'); ?>
                    <div class="btn_block mt_2">
                        <a href="<?php the_sub_field('button_link'); ?>" class="button blue_btn"><?php the_sub_field('button_text'); ?> <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-white.svg"></a>
                    </div>
                </div>
            </div>
			<?php endwhile; endif;?>
        </div>
    </div>
</section>
<section class="event_section wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title mb-2">
            <h2>Events</h2>
        </div>
        <div class="row event_List">
			<?php if( have_rows('events') ):
			while ( have_rows('events') ) : the_row();	?>
			<div class="col-12 col-sm-6 col-lg-4 evnt_item">
                <a href="<?php the_sub_field('link'); ?>" class="evnt_iner">
                    <img src="<?php the_sub_field('image'); ?>" class="evnt_thumb" alt="#" />
                    <div class="evenT_text">
                        <h4><?php the_sub_field('title'); ?></h4>
                        <p><?php the_sub_field('text'); ?></p>
                    </div>
                </a>         
            </div>
			<?php endwhile; endif;?>
        </div>
    </div>
</section>
</div>
<?php get_footer(); ?>
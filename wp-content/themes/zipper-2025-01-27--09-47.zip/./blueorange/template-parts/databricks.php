<?php
/*
Template Name: Databricks Page
*/
get_header();
?>
<div class="page-content">
<section class="banner_sec inner_banner partner_banner wi_full">
    <div class="container-xxl">
        <div class="banner_title no_indent text-center mb-3">
            <h1><?php the_field('heading'); ?></h2>
        </div>
    </div>
</section>
<section class="transform_tungson wi_full py_3 sec_after_sec bg_bluee">
    <div class="container-xxl">
        <div class="sec_title max_width text-center mb-0">
            <?php the_field('content'); ?>
            <div class="btn_block justify-content-center">
                <a href="<?php the_field('button_link'); ?>" class="button blue_btn"><?php the_field('button_text'); ?> <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-white.svg"></a>
            </div>
        </div>
    </div>
</section>
<section class="why_section wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title text-center mb-0">
            <h2><?php the_field('heading_2'); ?></h2>
        </div>
        <div class="row attend_list">
			<?php if( have_rows('content_2') ):
            while ( have_rows('content_2') ) : the_row();    ?>
            <div class="col-12 col-md-6 col-lg-4 attend_item">
                <div class="item_inner ul_tick text-center">
                    <h3><?php the_sub_field('title'); ?></h3>
					<?php the_sub_field('text'); ?>
                </div>
            </div>
			<?php endwhile; endif;?>
        </div>
    </div>
</section>
<section class="db_services databricks_services wi_full py_3 bg_bluee">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2><?php the_field('heading_4'); ?></h2>
        </div>
        <div class="recog_list row mt_2">
            <?php if( have_rows('d_services') ):
            while ( have_rows('d_services') ) : the_row();    ?>
            <div class="col-12 col-sm-6 col-md-4 recog_item">
                <div class="item_inner bg-white">
                    <div class="item_title">
                        <span class="item_icon">
                            <img src="<?php the_sub_field('icon'); ?>">
                        </span>
                        <h3><?php the_sub_field('heading'); ?></h3>
                    </div>
                    <?php the_sub_field('content_2'); ?>
                </div>
            </div>
            <?php endwhile; endif;?>
        </div>
    </div>
</section>
<section class="db_workshop_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title text-center max_width mb-0">
            <h2><?php the_field('heading_5'); ?></h2>
            <?php the_field('content_3'); ?>
        </div>
        <div class="row dbw_list">
			<?php if( have_rows('content_4') ):
            while ( have_rows('content_4') ) : the_row();    ?>
            <div class="col-12 col-sm-4 col-lg-4 dbw_item">
                <div class="item_inner">
                    <h3><?php the_sub_field('text'); ?></h3>
                </div>
            </div>
			<?php endwhile; endif;?>
        </div>
        <div class="btn_block justify-content-center">
            <a href="<?php the_field('button_link_1'); ?>" class="button blue_btn"><?php the_field('button_text_1'); ?> <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-white.svg"></a>
        </div>
    </div>
</section>

<section class="casestudy_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center mb-3">
            <h2><?php the_field('heading_6'); ?></h2>
            <?php the_field('content_5'); ?>
        </div>
        <div class="blog_wrapper row">
            <?php
            //$postids = get_field('case_studies');
            $postids = array(999, 1034, 1035 );

            $args = array( 'post_type' => 'case-studies' , "order" => "DESC", 'posts_per_page' => '3', 'post__in' => $postids);
            $query = new WP_Query( $args ); 
            if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : 
            $query->the_post();
             //$featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
                $featured_img = '';
                if ( has_post_thumbnail() ) {
                    $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large');
                    $featured_img = $large_image_url[0];
                } else {
                    //$featured_img = get_template_directory_uri() . '/assets/images/featured_default.svg';
                    $featured_img = get_field('case_studies_default_image', 'option');
                }
            ?>

            <?php get_template_part( 'template-parts/content/content-case-studies-block' ); ?>

            <?php endwhile; endif;  wp_reset_postdata(); ?>
        </div>
        <div class="btn_block v_mobile">
            <a href="<?php echo site_url(); ?>/?post_type=case-studies&s=&tax_blog_tags=case_studies_tags&tax_technology_tags=technology_studies_tags&tax_industries_tags=industries_studies_tags&techtags%5B%5D=databricks" class="button orange_btn">Learn More</a>
        </div>
    </div>
</section>

<!-- <section class="insight_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title btn_title">
            <h2>Blogs</h2>
            <a href="<?php echo site_url(); ?>/blog/" class="button orange_btn v_dsktop">Learn More</a>
        </div>
        <div class="insight_wrapper">
            <?php
            $args = array( 'post_type' => 'insights' , "order" => "DESC", 'posts_per_page' => '-1',);
            $query = new WP_Query( $args ); 
            if ( $query->have_posts() ) :
            $count = 1;
            while ( $query->have_posts() ) : 
            $query->the_post();
            $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
            $postid = get_the_ID();
            $terms = get_the_terms( $post->ID , 'insights-categories' );
            ?>
            <div class="item ins_item">
                <a href="<?php the_permalink(); ?>" class="item_inner">
                    <div class="item_icon">
                        <img src="<?php echo $featured_img_url; ?>" alt="#">
                    </div>
                    <div class="item_text">
                        <div class="insght_tags">
                            <?php foreach($terms as $cd){
                                echo '<span>' .$cd->name . '</span>';
                            } ?>
                        </div>
                        <h3><?php the_title(); ?></h3>
                        <div class="more_btn circle_morebtn">
                            <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-blue.svg">
                        </div>
                    </div>
                </a>
            </div>
            <?php $count++; endwhile; endif;  wp_reset_postdata(); ?>
        </div>
        <div class="btn_block v_mobile">
            <a href="<?php echo site_url(); ?>/blog/" class="button orange_btn">Learn More</a>
        </div>
    </div>
</section> -->
</div>
<?php get_footer(); ?>
<?php
/*
Template Name: Analytic Visualization
*/
get_header();
?>
<div class="page-content services_page">
<section class="banner_sec inner_banner services_banner new_banner wi_full">
    <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/analytics-desktop.png" class="desktop_banner w-100">
    <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/analytics-mobile.png" class="mobile_banner w-100">
    <div class="banner__wrap">
        <div class="container-xxl">
            <div class="banner_title text-center mb-3 title_service">
                <h1>Analytics <span>& Visualization</span></h1>
            </div>
            <div class="banner_content text-center">
                <div class="btn_block justify-content-center mt_2">
                    <a href="/contact-us/" class="button orange_btn">Get Started</a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="data_transformation wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>Data Transformation: Blue Orange's Analytics Solutions.</h2>
            <p>At Blue Orange, we transform data into action. From descriptive to prescriptive analytics, we streamline your journey toward automated decision-making. Our team enhances your analytics and BI strategies, leveraging flexible, modern infrastructures for improved data handling and visualization. This means deeper insights and smarter predictions, turning your data into real-time, actionable intelligence. Let Blue Orange unlock your data's full potential, leading your business to innovative success.</p>
        </div>
        <div class="btn_block justify-content-center">
            <a href="/contact" class="button orange_btn">Learn More</a>
        </div>
    </div>
</section>
<section class="data_analytics wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>Analytics & Visualization Services</h2>
            <p>We focus on enabling data-driven organizations, accelerating analytics value creation. Our team crafts and executes bespoke analytics strategies, empowering your business to make insightful, data-driven decisions and swiftly derive value from your data initiatives.</p>
        </div>
        <div class="rel_ser_List row">
            <div class="col-12 col-md-4 rel_ser_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/cloud-computing.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Analytics & BI Strategy</h3>
                    <p>Develop a comprehensive Analytics and BI strategy that aligns with your business objectives. Our approach ensures data-driven decision-making processes are integrated seamlessly across your organization, enhancing performance and competitive advantage.</p>
                </a>
            </div>
            <div class="col-12 col-md-4 rel_ser_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-migration.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Analytics Engineering</h3>
                    <p>Leverage our Analytics Engineering services to build robust, scalable data models and pipelines. We streamline the process of data transformation and preparation, enabling efficient analysis and insight generation to support strategic business initiatives.</p>
                </a>
            </div>
            <div class="col-12 col-md-4 rel_ser_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-integration.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Data Visualization & BI</h3>
                    <p>Transform complex datasets into intuitive, interactive visualizations with our Data Visualization and BI services. We design dashboards and reports that not only look great but also provide actionable insights, driving better business outcomes.</p>
                </a>
            </div>
        </div>
    </div>
</section>
<section class="data_databricks wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>Analytics & Visualization with Databricks</h2>
            <p>Leveraging Databricks for analytics and BI provides a unified platform that simplifies and enhances data-driven decision-making. As partners, we harness Databricks’ powerful analytics engine to offer real-time insights, seamless data integration, and advanced AI capabilities. The platform’s collaborative workspace fosters teamwork across data engineers, scientists, and business analysts, enabling the creation of robust, scalable data models and visualizations...</p>
        </div>
        <div class="btn_block justify-content-center">
            <a href="/contact" class="button orange_btn">Read More</a>
        </div>
    </div>
</section>
<section class="how_it_work wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>Common Analytics Use cases</h2>
            <p>As a company, our values are at the heart of everything we do, and they guide our decisions and actions. These values are essential to who we are as a company, and we will continue to strive to live up to them in all that we do.</p>
        </div>
        <div class="rel_ser_List row">
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Customer Segmentation</h3>
                     <p>Utilizing analytics to group customers based on behaviors and preferences for targeted marketing strategies.</p>
                </a>
                </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Sales Forecasting</h3>
                     <p>Employing predictive analytics to estimate future sales and inform inventory management.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Churn Prediction</h3>
                     <p>Analyzing customer data to predict and prevent customer attrition.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Fraud Detection</h3>
                     <p>Leveraging machine learning models to identify and mitigate fraudulent activities in real-time.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Market Basket Analysis</h3>
                     <p>Using association rules to understand product purchase patterns and optimize cross-selling opportunities.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Supply Chain Optimization</h3>
                     <p>Enhancing supply chain efficiency through analytics-driven demand forecasting and inventory management.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Risk Assessment</h3>
                     <p>Applying analytics to assess and mitigate various business risks, including credit risk and operational risk.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Energy Management</h3>
                     <p>Utilizing analytics to optimize energy consumption and improve sustainability in operations.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Sentiment Analysis</h3>
                     <p>Mining and analyzing customer feedback from social media and other platforms to gauge public sentiment and inform business strategies.</p>
                </a>
            </div>
        </div>
        <div class="btn_block justify-content-center">
            <a href="" class="button orange_btn">Learn More</a>
        </div>
    </div>
</section>
<section class="casestudy_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title btn_title">
            <h2>Case Studies</h2>
            <a href="<?php the_field('button_link_4'); ?>" class="button orange_btn v_dsktop"><?php the_field('button_text_4'); ?></a>
        </div>
        <div class="casestudy_wrapper">
            <?php
            $postids = get_field('case_studies');
            $args = array( 'post_type' => 'case-studies' , "order" => "DESC", 'posts_per_page' => '3', "post__in" => $postids);
            $query = new WP_Query( $args ); 
            if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : 
            $query->the_post();
            $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
            ?>
            <div class="item case_item">
                <a href="<?php the_permalink(); ?>" class="item_inner">
                    <div class="item_icon">
                        <img src="<?php echo $featured_img_url; ?>" alt="#">
                    </div>
                    <div class="item_text">
                        <h3><?php the_title(); ?></h3>
                        <?php
                              $excerpt       = get_the_excerpt();
                              $excerpt       = substr( $excerpt, 0, 100 );
                              $short_excerpt = substr( $excerpt, 0, strrpos( $excerpt, ' ' ) );
                              if ( ! empty( $short_excerpt ) ) { ?>
                                    <p><?php echo esc_html( $short_excerpt ); ?>&hellip;</p>
                           <?php } ?>
                        <div class="more_btn circle_morebtn">
                            <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-blue.svg">
                        </div>
                    </div>
                </a>
            </div>
            <?php endwhile; endif;  wp_reset_postdata(); ?>
        </div>
        <div class="btn_block v_mobile">
            <a href="<?php the_field('button_link_4'); ?>" class="button orange_btn"><?php the_field('button_text_4'); ?></a>
        </div>
    </div>
</section>
<section class="industry_sec wi_full">
    <div class="container-xxl">
        <div class="row align-items-baseline">
            <div class="col-12 col-lg-6">
                <div class="sec_title faq_title">
                    <h2>Frequently <br />asked questions</h2>
                    <div class="btn_block v_dsktop">
                        <a href="#" class="button orange_btn">Support</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="accordion_wrapper">
                    <div class="accordion faq_accordion" id="accordion" role="tablist" aria-multiselectable="true">
                        <div class="card">
                            <div class="card-header p-0" role="tab" id="accordion1">
                                <h3 class="collapsed" data-toggle="collapse" data-target="#accordion__1" role="button" aria-controls="accordion__1">How long are data strategy engagements?</h3>
                            </div>
                            <div id="accordion__1" class="collapse" role="tabpanel" aria-labelledby="accordion1" data-parent="#accordion">
                                <div class="card-body">
                                    <p>Typically 3-4 weeks. Text for example: By leveraging our approach to deploying machine learning (ML) workloads, we’ve boosted predictive analytics for a leading entertainment provider.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="btn_block v_mobile">
            <a href="#" class="button orange_btn">Support</a>
        </div>
    </div>
</section>
</div>
<?php get_footer(); ?>
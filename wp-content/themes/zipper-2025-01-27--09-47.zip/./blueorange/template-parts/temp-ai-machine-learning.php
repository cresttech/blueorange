<?php
/*
Template Name: AI & Machine Learning
*/
get_header();
?>
<div class="page-content services_page">
<section class="banner_sec inner_banner services_banner new_banner wi_full">
    <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/ai-machine-desktop.png" class="desktop_banner w-100">
    <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/ai-machine-mobile.png" class="mobile_banner w-100">
    <div class="banner__wrap">
        <div class="container-xxl">
            <div class="banner_title text-center mb-3 title_mi_service">
                <h1>AI <span>& Machine Learning</span></h1>
            </div>
            <div class="banner_content text-center">
                <p>Navigate the complexities of Cloud Data Platform Migration with Blue Orange, where our deep expertise in Databricks, AWS, Snowflake, and Microsoft Azure, coupled with our history of handling a wide array of legacy platforms, sets the stage for your seamless transition. We understand the unique challenges of shifting from traditional enterprise data warehouses to advanced cloud solutions.</p>
                <div class="btn_block justify-content-center mt_2">
                    <a href="/contact-us/" class="button orange_btn">Get Started</a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="ai_ml_service wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>AI &amp; Machine Learning Services</h2>
            <p>It can be challenging to translate ideas into AI solutions without the full range of experience that a seasoned team like Blue Orange provides. Our team is here to help your business design and deliver true value from its AI Agenda.</p>
        </div>
        <div class="rel_ser_List row">
            <div class="col-12 col-sm-6 col-lg-3 rel_ser_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/cloud-computing.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">AI Strategy</h3>
                    <p>Map your business’ journey into its AI-driven future.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-lg-3 rel_ser_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-migration.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Data Science</h3>
                    <p>Develop production solutions to your prioritized business problems and use cases.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-lg-3 rel_ser_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-migration.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Machine Learning</h3>
                    <p>Develop production-grade, repeatable, scalable machine learning systems.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-lg-3 rel_ser_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-migration.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Gen AI</h3>
                    <p>Validate and deliver your Generative AI use cases with our expert team.</p>
                </a>
            </div>
        </div>
        <div class="btn_block justify-content-center">
            <a href="/contact-us/" class="button blue_btn">Learn More</a>
        </div>
    </div>
</section>
<section class="overview_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title btn_title">
            <h2>The Blue Orange Approach.</h2>
            <a href="<?php echo site_url(); ?>/case-studies/" class="button blue_btn v_dsktop">Book a call <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icon-arrow-white.svg"></a>
        </div>
        <ul>
            <li>
                <h4>Use Case Prioritization</h4>
                <p>We'll team up to map your business, find top-value uses, and identify key data.</p>          
            </li>
            <li>
                <h4>ML/AI Prototyping</h4>
                <p>Validate the viability of the ML/AI solution through rapid prototyping.</p>
            </li>
            <li>
                <h4>Generative AI Solutions</h4>
                <p>With expert input from our data platform solutions specialists.</p>               
            </li>
            <li>
                <h4>ML Pipeline Creation</h4>
                <p>Build out robust, repeatable machine learning pipelines.</p>          
            </li>
            <li>
                <h4>Production ML Architecture</h4>
                <p>Design a fitting ML architecture for your ecosystem, offering cost-effective scalability.</p>
            </li>
            <li>
                <h4>MLOps Implementation</h4>
                <p>Operate your machine learning system at scale.</p>
            </li>
        </ul>
        <div class="btn_block v_mobile">
            <a href="/contact-us/" class="button blue_btn">Book a call <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icon-arrow-white.svg"></a>
        </div>
    </div>
</section>
<section class="databricks_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>Data Science &amp; AI with Databricks</h2>
            <p>Design and deliver your Data Science and AI solutions on top of the Databricks Lakehouse platform to take advantage of the streamlined, end-to-end data science workflow and scalable machine learning platform architecture. With Databricks, your Data Science team can spend less time worrying about data infrastructure, how to get their data, and how to translate their models into production and spend more time understanding the business problem and translating it into high-quality models.</p>
        </div>
        <div class="btn_block justify-content-center">
            <a href="/contact-us/" class="button orange_btn">Learn More</a>
        </div>
    </div>
</section>
<section class="casestudy_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title btn_title">
            <h2>Case Studies</h2>
            <a href="<?php the_field('button_link_4'); ?>" class="button orange_btn v_dsktop"><?php the_field('button_text_4'); ?></a>
        </div>
        <div class="casestudy_wrapper">
            <?php
            $postids = get_field('case_studies');
            $args = array( 'post_type' => 'case-studies' , "order" => "DESC", 'posts_per_page' => '3', "post__in" => $postids);
            $query = new WP_Query( $args ); 
            if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : 
            $query->the_post();
            $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
            ?>
            <div class="item case_item">
                <a href="<?php the_permalink(); ?>" class="item_inner">
                    <div class="item_icon">
                        <img src="<?php echo $featured_img_url; ?>" alt="#">
                    </div>
                    <div class="item_text">
                        <h3><?php the_title(); ?></h3>
                        <?php
                              $excerpt       = get_the_excerpt();
                              $excerpt       = substr( $excerpt, 0, 100 );
                              $short_excerpt = substr( $excerpt, 0, strrpos( $excerpt, ' ' ) );
                              if ( ! empty( $short_excerpt ) ) { ?>
                                    <p><?php echo esc_html( $short_excerpt ); ?>&hellip;</p>
                           <?php } ?>
                        <div class="more_btn circle_morebtn">
                            <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-blue.svg">
                        </div>
                    </div>
                </a>
            </div>
            <?php endwhile; endif;  wp_reset_postdata(); ?>
        </div>
        <div class="btn_block v_mobile">
            <a href="<?php the_field('button_link_4'); ?>" class="button orange_btn"><?php the_field('button_text_4'); ?></a>
        </div>
    </div>
</section>
<section class="industry_sec wi_full">
    <div class="container-xxl">
        <div class="row align-items-baseline">
            <div class="col-12 col-lg-6">
                <div class="sec_title faq_title">
                    <h2>Frequently <br />asked questions</h2>
                    <div class="btn_block v_dsktop">
                        <a href="#" class="button orange_btn">Support</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="accordion_wrapper">
                    <div class="accordion faq_accordion" id="accordion" role="tablist" aria-multiselectable="true">
                        <div class="card">
                            <div class="card-header p-0" role="tab" id="accordion1">
                                <h3 class="collapsed" data-toggle="collapse" data-target="#accordion__1" role="button" aria-controls="accordion__1">How long does a Machine Learning Proof of Concept Last?</h3>
                            </div>
                            <div id="accordion__1" class="collapse" role="tabpanel" aria-labelledby="accordion1" data-parent="#accordion">
                                <div class="card-body">
                                    <p>While it generally depends on the scope of the POC, we try to keep ML POCs to 8 weeks.</p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header p-0" role="tab" id="accordion2">
                                <h3 class="collapsed" data-toggle="collapse" data-target="#accordion__2" role="button" aria-controls="accordion__2">What is included in a machine learning POC?</h3>
                            </div>
                            <div id="accordion__2" class="collapse" role="tabpanel" aria-labelledby="accordion2" data-parent="#accordion">
                                <div class="card-body">
                                    <ol>
                                        <li>Translate business use case to ML solution
                                            <ul>
                                            <li>Exploratory data analysis</li>
                                            <li>Featurization</li>
                                            <li>Scalable model training and evaluation</li>
                                            <li>Model Tracking &amp; Model Registry (Usually with MLFlow)</li>
                                            </ul>
                                        </li>
                                        <li>Knowledge transfer</li>
                                        <li>Deliver a Working ML model, and documentation, and Identify of next steps</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header p-0" role="tab" id="accordion3">
                                <h3 class="collapsed" data-toggle="collapse" data-target="#accordion__3" role="button" aria-controls="accordion__3">What is out of scope for a Machine Learning POC?</h3>
                            </div>
                            <div id="accordion__3" class="collapse" role="tabpanel" aria-labelledby="accordion3" data-parent="#accordion">
                                <div class="card-body">
                                    <ul>
                                        <li>Data integration, ETL, and data cleansing outside of what is needed for the featurization.</li>
                                        <li>Improving any existing benchmark models.</li>
                                        <li>Front-end applications.</li>
                                        <li>CI/CD pipelines.</li>
                                        <li>Infrastructure setup and configuration.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="btn_block v_mobile">
            <a href="#" class="button orange_btn">Support</a>
        </div>
    </div>
</section>
</div>
<?php get_footer(); ?>
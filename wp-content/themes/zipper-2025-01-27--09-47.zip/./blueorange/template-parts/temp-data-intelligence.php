<?php
/*
Template Name: Data Intelligence Page
*/
get_header();
?>
<div class="page-content">
<section class="banner_sec inner_banner fintech__banner new_banner wi_full">
    <img src="<?php the_field('banner_image'); ?>" class="desktop_banner w-100">
    <img src="<?php the_field('image_mobile'); ?>" class="mobile_banner w-100">
    <div class="banner__wrap">
        <div class="container-xxl">
            <div class="banner_title text-center mb-3 no_indent">
                <h1><?php the_field('heading'); ?></h1>
            </div>
            <div class="banner_content text-center">
                <div class="btn_block justify-content-center mt_2">
                    <a href="<?php the_field('button_link'); ?>" class="button orange_btn"><?php the_field('button_text'); ?></a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="empowring_Sec empowering_health wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title text-center max_width mb-0">
            <h2><?php the_field('heading_1'); ?></h2>
            <?php the_field('content_1'); ?>
            <div class="btn_block justify-content-center mt-3 mb-3">
                <a href="<?php the_field('button_link_1'); ?>" class="button blue_btn"><?php the_field('button_text_1'); ?> <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-white.svg"></a>
            </div>
            <?php the_field('content_2'); ?>
        </div>
    </div>
</section>
<section class="centr_partner wi_full">
    <div class="container-xxl">
        <div class="sec_subtitle">Official Partners</div>
        <div class="centered_logos">
			<?php if( have_rows('partners') ):
			while ( have_rows('partners') ) : the_row();	?>
            <span class="cl_icon">
                <img src="<?php the_sub_field('image'); ?>">
            </span>
			<?php endwhile; endif;?>
        </div>
    </div>
</section>
<section class="tranform_health why_partner wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title text-center max_width mb-0">
            <h2><?php the_field('heading_2'); ?></h2>
        </div>
        <div class="row cexp_list">
			<?php if( have_rows('content_3') ):
			while ( have_rows('content_3') ) : the_row();	?>
            <div class="col-12 col-sm-6 col-lg-3 cexp_item">
                <div class="item_inner">
                    <img src="<?php the_sub_field('icon'); ?>">
                    <h3><?php the_sub_field('title'); ?></h3>
                    <p><?php the_sub_field('text'); ?></p>
                </div>
            </div>
			<?php endwhile; endif;?>
        </div>
    </div>
</section>
<section class="success_stori wi_full py_3 bg_bluee">
    <div class="container-xxl">
        <div class="sec_title max_width text-center mb-3">
            <h2><?php the_field('heading_3'); ?></h2>
            <?php the_field('content_4'); ?>
        </div>
        <div class="row thelth_list">	
			<?php if( have_rows('content_5') ):
			while ( have_rows('content_5') ) : the_row();	?>
            <div class="col-12 col-sm-6 col-lg-4 thelth_item">
                <div class="item_inner">
                    <img src="<?php the_sub_field('logo'); ?>">
                    <h3><?php the_sub_field('title'); ?></h3>
                    <?php the_sub_field('text'); ?>
                    <h4>Technologies Used</h4>
                    <div class="flex flex-wrap gap-2">
						<?php if( have_rows('technologies') ):
						while ( have_rows('technologies') ) : the_row();	?>
							<span class="bg-secondary/10 text-secondary px-2 py-1 rounded-full text-sm"><?php the_sub_field('content'); ?></span>
						<?php endwhile; endif;?>
                    </div>
                    <h4>Impact</h4>
                    <p><small><?php the_sub_field('impact'); ?></small></p>
                </div>
            </div> 
			<?php endwhile; endif;?>
        </div>
    </div>
</section>
<section class="nrf_attends wi_full py_3">
    <div class="container-xxl">
        <div class="max_large_width">
            <div class="sec_title text-center mb-5">
                <h2><?php the_field('heading_4'); ?></h2>
            </div>
            <div class="row align-items-center">
                <div class="col-12 col-lg-6">
                    <div class="sec_image">
                        <img src="<?php the_field('image_1'); ?>">
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="sec_content">
                       <?php the_field('content_6'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="realtime_Sec wi_full py_3 bg_bluee">
    <div class="container-xxl">
        <div class="row">
            <div class="col-12 col-lg-6">
                <div class="sec_content">
                    <h2><?php the_field('heading_5'); ?></h2>
                    <div class="rtc_list">
						<?php if( have_rows('content_7') ):
						while ( have_rows('content_7') ) : the_row();	?>
                        <div class="rtc_item">
                            <h3><?php the_sub_field('title'); ?></h3>
                            <p><?php the_sub_field('text'); ?></p>
                        </div>
						<?php endwhile; endif;?>
                    </div>
                    <div class="orange_txt">
                        <?php the_field('note'); ?>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="sec_form meeting_form">
                    <?php echo do_shortcode('[contact-form-7 id="6af721b" title="Contact form 1"]'); ?>
                </div>
            </div>
        </div>
    </div>
</section>
</div>
<?php get_footer(); ?>
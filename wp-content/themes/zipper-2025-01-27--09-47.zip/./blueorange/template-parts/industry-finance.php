<?php
/*
Template Name: Industry Detail Page
*/
get_header();
?>
<div class="page-content">
<section class="banner_sec inner_banner industry__banner new_banner wi_full">
    <img src="<?php the_field('banner_image'); ?>" class="desktop_banner w-100">
    <img src="<?php the_field('image_mobile'); ?>" class="mobile_banner w-100">
    <div class="banner__wrap">
        <div class="container-xxl">
            <div class="banner_title text-center mb-3 small_title">
                <h1><?php the_field('heading_1'); ?></h1>
            </div>
            <div class="banner_content text-center">
                <?php the_field('content_1'); ?>
                <div class="btn_block justify-content-center mt_2">
                    <a href="<?php the_field('button_link_1'); ?>" class="button orange_btn"><?php the_field('button_text_1'); ?></a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php if(get_field('heading_2') != '') { ?>
<section class="analysis_ec wi_full py_3 industry_more sec_after_sec">
    <div class="container-xxl">
        <div class="sec_title max_width text-center mb_32">
            <h2><?php the_field('heading_2'); ?></h2>
        </div>
        <div class="sec_content max_width text-center">
            <?php the_field('content_2'); ?>
			<?php if(get_field('button_text_2') != '') { ?>
            <div class="btn_block justify-content-center">
               <!--  <a href="<?php //the_field('button_link_2'); ?>" class="button orange_btn"><?php //the_field('button_text_2'); ?></a> -->
                <a class="button orange_btn show_more">Read More</a>
            </div>
			<?php } ?>
        </div>
    </div>
</section>
<?php } if(get_field('heading_8') != '') { ?>
<section class="key_strategy wi_full py_3 read_more_sec">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2><?php the_field('heading_8'); ?></h2>
        </div>
        <div class="strategy_List row mt_2 mb-5">
			<?php if( have_rows('strategies') ):
			while ( have_rows('strategies') ) : the_row();
			$count = count(get_field('strategies'));
			?>
			<div class="strategy_item more_item col-12 col-sm-6 col-lg-<?php if($count > 3) { echo '3'; } else { echo '4'; } ?>">
                <div class="item_inner">
                    <div class="item_title">
                        <span class="item_icon">
                            <?php if(get_sub_field('icon') != '') { ?><img src="<?php the_sub_field('icon'); ?>" alt="#"><?php } ?>
                        </span>
                        <h3><?php the_sub_field('title'); ?></h3>
                    </div>
                    <?php the_sub_field('text'); ?>
                </div>
            </div> 
			<?php endwhile; endif;?>   
        </div>
        <div class="sec_content max_width text-center v_dsktop">
            <div class=""><?php the_field('content_3'); ?></div>
        </div>
		<?php if(get_field('button_text_5') != '') { ?>
        <div class="btn_block">
            <a href="<?php the_field('button_link_5'); ?>" class="button orange_btn"><?php the_field('button_text_5'); ?></a>
        </div>
		<?php  } ?>
    </div>
</section>
<?php } if(get_field('heading_3') != '') { ?>
<section class="how_we_help wi_full py_3 read_more_sec">
    <div class="container-xxl">
        <div class="sec_title btn_title">
            <h2><?php the_field('heading_3'); ?></h2>
            <a href="<?php the_field('button_link_3'); ?>" class="button blue_btn v_dsktop"><?php the_field('button_text_3'); ?> <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-white.svg"></a>
        </div>
        <div class="help_List row mt_2">
			<?php if( have_rows('information') ):
			while ( have_rows('information') ) : the_row();	?>
            <div class="help_item more_item">
                <div class="item_inner">
                	<div class="item_title">
	                    <span class="item_icon">
	                        <?php if(get_sub_field('icon') != '') { ?><img src="<?php the_sub_field('icon'); ?>" alt="#"><?php } ?>
	                    </span>
	                    <h3><?php the_sub_field('title'); ?></h3>
	                </div>
                    <?php the_sub_field('text'); ?>
                </div>
            </div>
			<?php endwhile; endif;?>        
        </div>
        <div class="btn_block v_mobile">
            <a href="<?php the_field('button_link_3'); ?>" class="button blue_btn"><?php the_field('button_text_3'); ?> <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-white.svg"></a>
        </div>
    </div>
</section>
<?php } if(get_field('heading_6') != '') { ?>
<section class="tech_partner wi_full py_3 position-relative v_dsktop">
    <div class="container-xxl">
        <div class="sec_title text-center">
            <h2><?php the_field('heading_6'); ?></h2>
        </div>
        <div class="tlfi_wrapper row">
            <?php if( have_rows('financial_institutions') ):
            while ( have_rows('financial_institutions') ) : the_row();  ?>
                <div class="item"><img src="<?php the_sub_field('image'); ?>" alt="#"></div>
            <?php endwhile; endif;?>
        </div>
        <div class="sec_subtitle"><?php the_field('heading_6'); ?></div>
    </div>
</section>
<?php } if(get_field('heading_5') != '') { ?>
<section class="casestudy_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title btn_title">
        	<h2><?php the_field('heading_5'); ?></h2>
            <?php
                $filter_data = get_field('select_case_study_category');
                $case_slug = $filter_data->slug;
            ?>
            <form role="search" id="searchform" action="/" method="get">
                <input type="text" name="post_type" value="case-studies" / style="display: none;">
                <input type="hidden" value="industries_studies_tags" name="tax_industries_tags" />
                <input type="hidden" name="indtags[]" value="<?php echo $case_slug; ?>">
                <input value="" name="s" type="hidden">
                <input type="submit" class="button orange_btn v_dsktop" value="<?php the_field('button_text_4'); ?>" />
            </form>
        	<!-- <a href="<?php //the_field('button_link_4'); ?>" class="button orange_btn v_dsktop"><?php //the_field('button_text_4'); ?></a> -->
        </div>

        <div class="blog_wrapper row">
            <?php 
                $postids = get_field('case_studies');
                $args = array( 'post_type' => 'case-studies' , "order" => "DESC", 'posts_per_page' => '3', 'post__in' => $postids);

                $query = new WP_Query( $args ); 
                if ( $query->have_posts() ) { ?>
                   <?php while ( $query->have_posts() ) {
                      $query->the_post();  
                        get_template_part( 'template-parts/content/content-case-studies-block' ); 
                    } ?>
                <?php wp_reset_postdata();
                the_posts_pagination(); 
            } ?>
        </div>
        <div class="btn_block v_mobile">
            <form role="search" id="searchform" action="/" method="get">
                <input type="text" name="post_type" value="case-studies" / style="display: none;">
                <input type="hidden" value="industries_studies_tags" name="tax_industries_tags" />
                <input type="hidden" name="indtags[]" value="<?php echo $case_slug; ?>">
                <input value="" name="s" type="hidden">
                <input type="submit" class="button orange_btn" value="<?php the_field('button_text_4'); ?>" />
            </form>
        </div>
    </div>
</section>
<?php } if(get_field('heading_4') != '') { ?>
<section class="tech_partner wi_full py_3 position-relative v_dsktop">
    <div class="container-xxl">
        <div class="sec_title text-center">
            <h2><?php the_field('heading_4'); ?></h2>
        </div>
        <div class="lds_wrapper row">
            <?php if( have_rows('logos') ):
            while ( have_rows('logos') ) : the_row();   ?>
                <div class="item"><img src="<?php the_sub_field('image'); ?>" alt="#"></div>
            <?php endwhile; endif;?>
        </div>
        <div class="sec_subtitle"><?php the_field('heading_4'); ?></div>
    </div>
</section>
<?php } ?>
</div>
<?php get_footer(); ?>
<?php

/*
Template Name: Data Engineering
*/
get_header();
?>
<div class="page-content services_page">
<section class="banner_sec inner_banner services_banner new_banner wi_full">
    <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-engg-desktop.png" class="desktop_banner w-100">
    <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-engg-mobile.png" class="mobile_banner w-100">
    <div class="banner__wrap">
        <div class="container-xxl">
            <div class="banner_title text-center mb-3 title_service">
                <h1>Data <span>Engineering</span></h1>
            </div>
            <div class="banner_content text-center">
                <p>At Blue Orange, our comprehensive Data Engineering Services enable organizations to unlock the true potential of their data. Data Engineering is the backbone of every data driven organization and can enable organizations to make the most of their data by being prepared to take advantage of machine learning & AI.</p>
                <div class="btn_block justify-content-center mt_2">
                    <a href="/contact-us/" class="button orange_btn">Get Started</a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="data_engg wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>Our data engineering teams are the backbone of any data-driven solution.</h2>
            <p>At Blue Orange we’ve seen clients across industries require data engineering at different stages based on their data maturity and organizational goals. Services we provided:</p>
        </div>
        <div class="rel_ser_List row col_w_50">
            <div class="col-12 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/cloud-computing.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Data Platform Architecture</h3>
                    <p>Design and implement scalable, efficient data architectures tailored to organizational needs, ensuring seamless data flow and storage for advanced analytics and decision-making.</p>
                </a>
            </div>
            <div class="col-12 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-migration.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Data Migration</h3>
                    <p>Securely transfer data between systems, platforms, or environments with minimal downtime, ensuring data integrity, consistency, and optimized performance post-migration.</p>
                </a>
            </div>
            <div class="col-12 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-integration.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Data Integration</h3>
                    <p>Combine data from various sources into a unified view, facilitating consistent, accurate, and comprehensive data analysis and reporting across the organization.</p>
                </a>
            </div>
            <div class="col-12 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-modeling.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Data Modeling</h3>
                    <p>Construct logical and physical data models to represent complex data structures, enabling efficient data storage, retrieval, and analysis, and supporting business processes.</p>
                </a>
            </div>
            <div class="col-12 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/02/data-products.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Data Products</h3>
                    <p>Develop and deliver data-driven products or services, such as analytics dashboards, machine learning models, or data APIs, to drive actionable insights and business value.</p>
                </a>
            </div>
        </div>
    </div>
</section>
<section class="how_it_work wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>How we work</h2>
            <p>Can enable organizations to make the most of their data by being prepared to take<br />advantage of machine learning &amp; AI.</p>
        </div>
        <div class="rel_ser_List row  col_w_50">
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Design and Plan Our Data Platform Architecture (Strategy Consulting Session)</h3>
                     <p>Engage with our experts in a strategy consulting session to design and plan your data platform architecture. We assess your current infrastructure, identify areas for improvement, and create a strategic roadmap tailored to your business goals. This session sets the foundation for a scalable and efficient data ecosystem, leveraging our expertise in the Databricks platform and beyond.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Plan Out Data Migration</h3>
                     <p>Work with us to meticulously plan your cloud data migration. We help you navigate the complexities of moving data between systems or to the cloud, ensuring a seamless transition with minimal disruption. Our planning process includes risk assessment, tool selection, and a phased implementation strategy to ensure data integrity and continuity.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Integrate Our Data Engineering Expertise</h3>
                     <p>Benefit from our specialized data engineering expertise by integrating our professionals into your existing team. This collaboration enhances your team’s capabilities, providing the technical skills and industry insights needed to accelerate your data projects. Our experts can lead or support <span class="more__wrapper"> marketing, thereby enhancing operational efficiency and customer satisfaction.</span> <span class="show_more">Read More</span></p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Build Out a Team to Support an End-to-End Data Engineering Practice</h3>
                     <p>Let us construct a dedicated team to support your end-to-end data engineering practice. From initial data strategy to operational analytics, our team will manage and execute the full lifecycle of your data engineering initiatives. This approach ensures a cohesive and comprehensive handling <span class="more__wrapper"> marketing, thereby enhancing operational efficiency and customer satisfaction.</span> <span class="show_more">Read More</span></p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 rel_ser_item more_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Bring a Team to Execute a Data Engineering Use Case</h3>
                     <p>Deploy our team to take your data engineering use case from ideation to production. We manage the entire process, including planning, development, testing, and deployment, ensuring a successful transition to a live environment. Our team&#8217;s expertise ensures that your data <span class="more__wrapper"> marketing, thereby enhancing operational efficiency and customer satisfaction.</span> <span class="show_more">Read More</span></p>
                </a>
            </div>
        </div>
        <div class="btn_block justify-content-center">
            <a href="" class="button orange_btn">Learn More</a>
        </div>
    </div>
</section>
<section class="approach_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>Blue Orange Approach</h2>
            <p>At Blue Orange, we believe in leveraging the best-of-breed technologies, tailored precisely to fit your organization&#8217;s unique needs and use cases. Our focus is on delivering tangible value swiftly, allowing you to demonstrate ROI at an accelerated pace.</p>
            <p>We specialize in cloud-native, modern data technologies, ranging from open-source solutions to commercial tools, ensuring flexibility and scalability at every step of your data journey. Our approach emphasizes a simplified, end-to-end data platform architecture, minimizing ongoing architecture decisions and reducing the complexity of integrating new use cases and capabilities seamlessly.</p>
            <p>Explore how our data engineering services can empower your organization to unlock the full potential of your data, driving innovation and success.</p>
        </div>
    </div>
</section>
<section class="databricks_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2>Data Engineering with Databricks.</h2>
            <p>Harness the power of Databricks for your data engineering needs and transform how your organization processes and leverages data. Databricks simplifies data ingestion, making it easier to bring your data into the platform, while its automated ETL processing reduces manual effort and accelerates time to insight. The platform ensures reliable workflow orchestration, allowing seamless data workflows that drive your business forward.</p>
        </div>
        <div class="databrick_List row">
            <div class="col-12 col-sm-6 col-md-4 databrick_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Simplified Data Ingestion</h3>
                    <p>Streamline the process of importing data into the platform, ensuring a smooth and efficient data flow from various sources.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 databrick_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Automated ETL Processing</h3>
                     <p>Leverage advanced automation to transform your data efficiently, minimizing manual tasks and errors.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 databrick_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Reliable Workflow Orchestration</h3>
                     <p>Achieve dependable data processing workflows that are essential for critical data operations and decision-making.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 databrick_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">End-to-End Observability &amp; Monitoring</h3>
                     <p>Gain comprehensive visibility into your data pipelines, ensuring performance and reliability are always maintained.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 databrick_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Next-Generation Data Processing Engine</h3>
                     <p>Utilize Databricks’ cutting-edge processing capabilities to handle complex data operations at scale.</p>
                </a>
            </div>
            <div class="col-12 col-sm-6 col-md-4 databrick_item">
                <a class="item_inner">
                    <span class="item_icon">
                        <img src="https://stg-blueorangev2-staging.kinsta.cloud/wp-content/uploads/2024/04/tick-icon.png" alt="#">
                    </span>
                    <h3 class="h4 mb-3">Foundation of Governance, Reliability, and Performance</h3>
                     <p>Build your data solutions on a platform known for its robust governance, reliability, and high performance.</p>
                </a>
            </div>
        </div>
    </div>
</section>
<section class="casestudy_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title btn_title">
            <h2>Case Studies</h2>
            <a href="<?php the_field('button_link_4'); ?>" class="button orange_btn v_dsktop"><?php the_field('button_text_4'); ?></a>
        </div>
        <div class="casestudy_wrapper">
            <?php
            $postids = get_field('case_studies');
            $args = array( 'post_type' => 'case-studies' , "order" => "DESC", 'posts_per_page' => '3', "post__in" => $postids);
            $query = new WP_Query( $args ); 
            if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : 
            $query->the_post();
            $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
            ?>
            <div class="item case_item">
                <a href="<?php the_permalink(); ?>" class="item_inner">
                    <div class="item_icon">
                        <img src="<?php echo $featured_img_url; ?>" alt="#">
                    </div>
                    <div class="item_text">
                        <h3><?php the_title(); ?></h3>
                        <?php
                              $excerpt       = get_the_excerpt();
                              $excerpt       = substr( $excerpt, 0, 100 );
                              $short_excerpt = substr( $excerpt, 0, strrpos( $excerpt, ' ' ) );
                              if ( ! empty( $short_excerpt ) ) { ?>
                                    <p><?php echo esc_html( $short_excerpt ); ?>&hellip;</p>
                           <?php } ?>
                        <div class="more_btn circle_morebtn">
                            <img src="<?php bloginfo('template_url') ?>/assets/images/icon-arrow-blue.svg">
                        </div>
                    </div>
                </a>
            </div>
            <?php endwhile; endif;  wp_reset_postdata(); ?>
        </div>
        <div class="btn_block v_mobile">
            <a href="<?php the_field('button_link_4'); ?>" class="button orange_btn"><?php the_field('button_text_4'); ?></a>
        </div>
    </div>
</section>
<section class="industry_sec wi_full">
    <div class="container-xxl">
        <div class="row align-items-baseline">
            <div class="col-12 col-lg-6">
                <div class="sec_title faq_title">
                    <h2>Frequently <br />asked questions</h2>
                    <div class="btn_block v_dsktop">
                        <a href="#" class="button orange_btn">Support</a>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="accordion_wrapper">
                    <div class="accordion faq_accordion" id="accordion" role="tablist" aria-multiselectable="true">
                        <div class="card">
                            <div class="card-header p-0" role="tab" id="accordion1">
                                <h3 class="collapsed" data-toggle="collapse" data-target="#accordion__1" role="button" aria-controls="accordion__1">How long are data strategy engagements?</h3>
                            </div>
                            <div id="accordion__1" class="collapse" role="tabpanel" aria-labelledby="accordion1" data-parent="#accordion">
                                <div class="card-body">
                                    <p>Typically 3-4 weeks. Text for example: By leveraging our approach to deploying machine learning (ML) workloads, we’ve boosted predictive analytics for a leading entertainment provider.</p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header p-0" role="tab" id="accordion2">
                                <h3 class="collapsed" data-toggle="collapse" data-target="#accordion__2" role="button" aria-controls="accordion__2">How much time will be required from my team?</h3>
                            </div>
                            <div id="accordion__2" class="collapse" role="tabpanel" aria-labelledby="accordion2" data-parent="#accordion">
                                <div class="card-body">
                                    <p>Our advanced data and analytics expertise turns complex financial data, both proprietary and 3rd party, into valuable and actionable insights.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="btn_block v_mobile">
            <a href="#" class="button orange_btn">Support</a>
        </div>
    </div>
</section>
</div>
<?php get_footer(); ?>
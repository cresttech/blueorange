<?php
/*
* Template Name: GenAI Solutions Page
* Template Post Type: services
*/
get_header();
?>
<div class="page-content">
<section class="banner_sec inner_banner blog_banner new_banner py_3 wi_full">
    <img src="/wp-content/uploads/2024/05/blog-banner.png" class="desktop_banner w-100">
    <img src="/wp-content/uploads/2024/05/blog-banner-mobile.png" class="mobile_banner w-100">
    <div class="banner__wrap">
        <div class="container-xxl">
            <div class="banner_title text-center mb-3">
                <h1><?php the_field('banner_heading'); ?></h1>
            </div>
        </div>
    </div>
    </section>


    <section class="transform_tungson wi_full py_3">
        <div class="container-xxl">
            <div class="sec_title max_width text-center">
                <h2><?php the_field('transform_heading'); ?></h2>
                <?php the_field('transform_content'); ?>
            </div>
        </div>
    </section>
    <section class="copilot_insight wi_full">
        <div class="container-xxl">
            <div class="sec_title max_width text-center">
                <h2><?php the_field('copilot_heading'); ?></h2>
                <?php the_field('copilot_content_1'); ?>
            </div>
            <div class="copilot_list row mt_2">
                <?php if (have_rows('copilot_detail')):
                    while (have_rows('copilot_detail')) : the_row();    ?>
                        <div class="col-12 col-sm-6 copilot_item">
                            <div class="item_inner">
                                <h3><?php the_sub_field('title'); ?></h3>
                                <?php the_sub_field('content'); ?>
                            </div>
                        </div>
                <?php endwhile;
                endif; ?>
            </div>
        </div>
    </section>
    <section class="partner_video wi_full py_3">
        <div class="container-xxl">
            <div class="row align-items-center">
                <div class="col-12 col-lg-6">
                    <div class="sec_title mb_3">
                        <h2><?php the_field('copilot_title'); ?></h2>
                        <?php the_field('copilot_content'); ?>
                        <div class="btn_block">
                            <a href="<?php the_field('copilot_video_button_link'); ?>" class="button orange_btn"><?php the_field('copilot_video_button'); ?></a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="video_boxx">
                        <iframe width="560" height="315" src="<?php the_field('copilot_video_link'); ?>"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php get_footer(); ?>
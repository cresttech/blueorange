<?php
/*
Template Name: Partner Page
*/
get_header();
?>
<div class="page-content">
<section class="banner_sec inner_banner new_banner banner_max_h wi_full">
    <img src="<?php the_field('image'); ?>" class="desktop_banner w-100">
    <img src="<?php the_field('image_mobile'); ?>" class="mobile_banner w-100">
    <div class="banner__wrap">
        <div class="container-xxl">
            <div class="banner_title text-center mb-3">
                <h1><?php the_field('heading'); ?></h1>
            </div>
            <div class="banner_content text-center">
                <div class="btn_block justify-content-center mt_2">
                    <a href="<?php the_field('button_link'); ?>" class="button orange_btn"><?php the_field('button_text'); ?></a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="about_partner wi_full py_3 sec_after_sec">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2><?php the_field('heading_2'); ?></h2>
            <?php the_field('content_2'); ?>
        </div>
    </div>
</section>
<section class="partnership_sec wi_full">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2><?php the_field('heading_3'); ?></h2>
        </div>
        <div class="partnership_List row mt_2">
            <?php if( have_rows('partnership') ):
            while ( have_rows('partnership') ) : the_row();    ?>
            <div class="list_item">
                <div class="item_inner">
                    <img src="<?php the_sub_field('image'); ?>">
                    <?php the_sub_field('content'); ?>
					<?php if(get_sub_field('button_text') != '') { ?>
                    <div class="btn_block">
                        <a href="<?php the_sub_field('button_link'); ?>" class="button orange_btn text-center w-100"><?php the_sub_field('button_text'); ?></a>
                    </div>
					<?php } ?>
                </div>
            </div>
            <?php endwhile; endif;?>
        </div>
    </div>
</section>
<section class="certificate_sec wi_full py_3">
    <div class="container-xxl">
        <div class="sec_title max_width text-center">
            <h2><?php the_field('heading_4'); ?></h2>
            <?php the_field('content_3'); ?>
        </div>
        <div class="certificate_logo row mt_3">
            <?php if( have_rows('certification') ):
            while ( have_rows('certification') ) : the_row();    ?>
            <div class="logo_item">
                <img src="<?php the_sub_field('image_1'); ?>" alt="#">
            </div>
            <?php endwhile; endif;?>
        </div>
    </div>
</section>
</div>
<?php get_footer(); ?>